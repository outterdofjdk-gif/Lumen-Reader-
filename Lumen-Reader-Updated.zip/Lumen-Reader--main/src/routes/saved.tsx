import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/layout/SiteHeader";
import { Toaster } from "@/components/ui/sonner";
import { getSavedArticles, removeSavedArticle, type SavedArticle } from "@/lib/articles";
import { sourceFor } from "@/lib/sources/registry";
import { Bookmark, Clock, Trash2, ExternalLink, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export const Route = createFileRoute("/saved")({
  head: () => ({ meta: [{ title: "Saved articles — Lumen Reader" }] }),
  component: SavedPage,
});

function SavedPage() {
  const [articles, setArticles] = useState<SavedArticle[]>([]);

  useEffect(() => {
    setArticles(getSavedArticles());
    const onChange = () => setArticles(getSavedArticles());
    window.addEventListener("reader:saved-changed", onChange);
    return () => window.removeEventListener("reader:saved-changed", onChange);
  }, []);

  const handleRemove = (e: React.MouseEvent, id: string, title: string) => {
    e.preventDefault();
    e.stopPropagation();
    removeSavedArticle(id);
    toast.info(`Removed "${title}" from saved articles`);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Toaster richColors position="top-center" />
      <SiteHeader />
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-10 py-10 sm:py-16">
        <header className="mb-10">
          <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground mb-2 flex items-center gap-2">
            <Bookmark className="size-3" /> Saved for later
          </div>
          <h1 className="font-reading text-3xl sm:text-5xl font-semibold tracking-tight">Saved articles</h1>
          <p className="mt-3 text-muted-foreground">
            {articles.length === 0 
              ? "Your reading list is empty. Bookmark articles from the feed to read them later."
              : `You have ${articles.length} article${articles.length === 1 ? "" : "s"} waiting for you.`}
          </p>
        </header>

        {articles.length === 0 ? (
          <div className="py-20 text-center rounded-3xl border border-dashed border-border-subtle bg-surface/50">
            <div className="size-12 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Bookmark className="size-6 text-muted-foreground opacity-40" />
            </div>
            <h3 className="text-lg font-medium mb-1">No saved articles yet</h3>
            <p className="text-sm text-muted-foreground mb-6">Explore the feed to find something interesting to read.</p>
            <Button asChild variant="outline" className="rounded-full">
              <Link to="/">Go to feed</Link>
            </Button>
          </div>
        ) : (
          <div className="grid gap-4">
            {articles.map((a) => {
              const src = sourceFor(a.source);
              return (
                <div 
                  key={a.id}
                  className="group relative rounded-2xl bg-surface border border-border-subtle hover:border-primary/20 hover:shadow-md transition-all overflow-hidden"
                >
                  <Link 
                    to="/" 
                    search={{ articleId: a.id }}
                    className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 p-4 sm:p-5"
                  >
                    {a.image && (
                      <div className="shrink-0 w-full sm:w-32 aspect-video sm:aspect-square rounded-lg overflow-hidden bg-muted">
                        <img src={a.image} alt="" className="w-full h-full object-cover transition group-hover:scale-105" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">
                        {src.favicon && <img src={src.favicon} alt="" className="size-3 rounded-sm" />}
                        <span>{src.name}</span>
                        <span className="size-0.5 rounded-full bg-muted-foreground/40" />
                        <span>{new Date(a.savedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</span>
                      </div>
                      <h2 className="font-reading text-lg sm:text-xl font-semibold leading-tight group-hover:text-primary transition-colors line-clamp-2 mb-2">
                        {a.title}
                      </h2>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="inline-flex items-center gap-1"><Clock className="size-3" />{a.readingTime} min</span>
                        {a.progress > 0 && (
                          <div className="flex items-center gap-2">
                            <div className="w-16 h-1 rounded-full bg-muted overflow-hidden">
                              <div className="h-full bg-primary" style={{ width: `${a.progress}%` }} />
                            </div>
                            <span>{a.progress}% read</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 sm:self-center">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-9 rounded-full text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                        onClick={(e) => handleRemove(e, a.id, a.title)}
                      >
                        <Trash2 className="size-4" />
                      </Button>
                      <div className="hidden sm:flex size-9 rounded-full bg-primary/5 text-primary items-center justify-center group-hover:bg-primary group-hover:text-white transition-colors">
                        <ChevronRight className="size-5" />
                      </div>
                    </div>
                  </Link>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}

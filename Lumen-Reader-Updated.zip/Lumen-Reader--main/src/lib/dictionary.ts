import { translateWord, type TranslationContext } from "./reader-cache";

export type DictMeaning = {
  partOfSpeech: string;
  definitions: { definition: string; example?: string }[];
};

export type DictEntry = {
  word: string;
  phonetic?: string;
  audio?: string;
  audioSource?: string;
  meanings: DictMeaning[];
  sourceUrl?: string;
  translation?: string; // Integrated translation
};

const CACHE = new Map<string, DictEntry | null>();
const PRON_CACHE_KEY = "reader.pron.cache.v1";

type PronCache = Record<string, { url: string; source: string }>;

function loadPronCache(): PronCache {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(localStorage.getItem(PRON_CACHE_KEY) || "{}");
  } catch {
    return {};
  }
}
let pronCache: PronCache | null = null;
function pron(): PronCache {
  if (!pronCache) pronCache = loadPronCache();
  return pronCache;
}
function setPron(word: string, url: string, source: string) {
  pron()[word.toLowerCase()] = { url, source };
  try {
    localStorage.setItem(PRON_CACHE_KEY, JSON.stringify(pron()));
  } catch {
    /* quota */
  }
}

export function lemmaCandidates(word: string): string[] {
  const w = word.toLowerCase();
  const out = new Set<string>();
  const add = (s: string) => {
    if (s && s !== w && s.length >= 2) out.add(s);
  };
  if (w.endsWith("ies") && w.length > 3) add(w.slice(0, -3) + "y");
  if (w.endsWith("sses")) add(w.slice(0, -2));
  if (w.endsWith("xes") || w.endsWith("zes") || w.endsWith("ches") || w.endsWith("shes"))
    add(w.slice(0, -2));
  if (w.endsWith("s") && !w.endsWith("ss") && w.length > 3) add(w.slice(0, -1));
  if (w.endsWith("ied") && w.length > 3) add(w.slice(0, -3) + "y");
  if (w.endsWith("ed") && w.length > 3) {
    add(w.slice(0, -2));
    add(w.slice(0, -1));
    const stem = w.slice(0, -2);
    if (stem.length >= 3 && stem[stem.length - 1] === stem[stem.length - 2]) {
      add(stem.slice(0, -1));
    }
  }
  if (w.endsWith("ing") && w.length > 4) {
    add(w.slice(0, -3));
    add(w.slice(0, -3) + "e");
    const stem = w.slice(0, -3);
    if (stem.length >= 3 && stem[stem.length - 1] === stem[stem.length - 2]) {
      add(stem.slice(0, -1));
    }
  }
  if (w.endsWith("ly") && w.length > 3) add(w.slice(0, -2));
  if (w.endsWith("er") && w.length > 3) add(w.slice(0, -2));
  if (w.endsWith("est") && w.length > 4) add(w.slice(0, -3));
  return Array.from(out);
}

type AudioCandidate = { url: string; source: string };

function classifySource(audioUrl: string): string {
  if (!audioUrl) return "unknown";
  if (/-uk\.mp3/i.test(audioUrl)) return "cambridge-uk";
  if (/-us\.mp3/i.test(audioUrl)) return "cambridge-us";
  if (/ssec\.cambridge\.org|dictionary\.cambridge/i.test(audioUrl)) return "cambridge";
  if (/wikimedia|wikipedia/i.test(audioUrl)) return "wiktionary";
  if (/merriam/i.test(audioUrl)) return "merriam-webster";
  return "dictionaryapi";
}

async function fetchFromDictionaryApi(
  key: string,
): Promise<{ entry: DictEntry | null; audios: AudioCandidate[] }> {
  try {
    const res = await fetch(
      `https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(key)}`,
      { signal: AbortSignal.timeout(5000) }
    );
    if (!res.ok) return { entry: null, audios: [] };
    const data = await res.json();
    const first = Array.isArray(data) ? data[0] : null;
    if (!first) return { entry: null, audios: [] };

    const audios: AudioCandidate[] = [];
    for (const ph of first.phonetics || []) {
      if (ph.audio && ph.audio.length) {
        let url = ph.audio;
        if (url.startsWith("//")) url = "https:" + url;
        audios.push({ url, source: classifySource(url) });
      }
    }
    const order = (s: string) =>
      s === "cambridge-uk" ? 0 : s === "cambridge-us" ? 1 : s === "cambridge" ? 2 : 3;
    audios.sort((a, b) => order(a.source) - order(b.source));

    const phoneticObj = first.phonetics?.find(
      (p: { text?: string; audio?: string }) => p.text || p.audio,
    );
    const entry: DictEntry = {
      word: first.word,
      phonetic: first.phonetic || phoneticObj?.text,
      audio: audios[0]?.url,
      audioSource: audios[0]?.source,
      meanings: (first.meanings || []).map((m: any) => ({
        partOfSpeech: m.partOfSpeech,
        definitions: (m.definitions || []).slice(0, 3).map((d: any) => ({
          definition: d.definition,
          example: d.example,
        })),
      })),
      sourceUrl: first.sourceUrls?.[0],
    };
    return { entry, audios };
  } catch {
    return { entry: null, audios: [] };
  }
}

async function fetchFromWiktionary(key: string): Promise<AudioCandidate | null> {
  try {
    const res = await fetch(
      `https://en.wiktionary.org/api/rest_v1/page/definition/${encodeURIComponent(key)}`,
      { signal: AbortSignal.timeout(5000) }
    );
    if (!res.ok) return null;
    const data = await res.json();
    const en = data?.en;
    if (!Array.isArray(en)) return null;
    for (const section of en) {
      const audio = section?.audio;
      if (typeof audio === "string" && audio.startsWith("http")) {
        return { url: audio, source: "wiktionary" };
      }
    }
    return null;
  } catch {
    return null;
  }
}

async function lookupOnce(
  key: string,
): Promise<{ entry: DictEntry | null; audios: AudioCandidate[] }> {
  if (CACHE.has(key)) {
    const e = CACHE.get(key)!;
    return { entry: e, audios: e?.audio ? [{ url: e.audio, source: e.audioSource || "unknown" }] : [] };
  }
  const dapi = await fetchFromDictionaryApi(key);
  CACHE.set(key, dapi.entry);
  return dapi;
}

/**
 * Enhanced lookup with integrated translation and context support.
 */
export async function lookupWord(
  word: string, 
  context?: TranslationContext
): Promise<DictEntry | null> {
  const original = word.toLowerCase();
  
  // 1) check pronunciation cache for instant audio
  const cachedPron = pron()[original];
  let initialEntry: Partial<DictEntry> = { word: original };
  
  if (cachedPron) {
    initialEntry.audio = cachedPron.url;
    initialEntry.audioSource = cachedPron.source;
  }

  const tried: string[] = [];
  const keys = [original, ...lemmaCandidates(original)];
  let bestEntry: DictEntry | null = null;
  const allAudios: AudioCandidate[] = [];

  // Parallel lookup for dictionary and translation
  const translationPromise = translateWord(context || original);

  for (const k of keys) {
    tried.push(k);
    const r = await lookupOnce(k);
    if (!bestEntry && r.entry) bestEntry = r.entry;
    for (const a of r.audios) allAudios.push(a);
    if (allAudios.length) break;
  }

  // Fallback: Wiktionary
  if (!allAudios.length) {
    const w = await fetchFromWiktionary(original);
    if (w) allAudios.push(w);
  }

  let finalEntry: DictEntry;
  if (allAudios.length) {
    const chosen = allAudios[0];
    setPron(original, chosen.url, chosen.source);
    finalEntry = {
      ...(bestEntry || { word: original, meanings: [] }),
      audio: chosen.url,
      audioSource: chosen.source,
    };
  } else {
    finalEntry = bestEntry || (initialEntry as DictEntry);
  }

  // Wait for translation to complete and attach it
  finalEntry.translation = await translationPromise;

  return finalEntry;
}

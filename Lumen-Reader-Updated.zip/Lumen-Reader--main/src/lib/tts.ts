export type Accent = "en-US" | "en-GB";

let voicesCache: SpeechSynthesisVoice[] = [];
let isVoicesLoading = false;
const voicesListeners: ((voices: SpeechSynthesisVoice[]) => void)[] = [];

/**
 * Robustly load voices with a promise and cache.
 * Handles inconsistent 'voiceschanged' event across browsers.
 */
function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  if (voicesCache.length) return Promise.resolve(voicesCache);
  if (isVoicesLoading) {
    return new Promise((resolve) => voicesListeners.push(resolve));
  }

  isVoicesLoading = true;
  return new Promise((resolve) => {
    const checkVoices = () => {
      const v = window.speechSynthesis.getVoices();
      if (v.length) {
        voicesCache = v;
        isVoicesLoading = false;
        resolve(v);
        voicesListeners.forEach((l) => l(v));
        voicesListeners.length = 0;
        return true;
      }
      return false;
    };

    if (checkVoices()) return;

    const handler = () => {
      if (checkVoices()) {
        window.speechSynthesis.removeEventListener("voiceschanged", handler);
      }
    };
    window.speechSynthesis.addEventListener("voiceschanged", handler);

    // Timeout fallback for browsers that don't fire voiceschanged
    setTimeout(() => {
      if (isVoicesLoading) {
        checkVoices();
        isVoicesLoading = false;
        resolve(voicesCache);
      }
    }, 3000);
  });
}

/**
 * Finds the best available voice for a given accent.
 * Prioritizes high-quality (natural/premium) voices.
 */
function findBestVoice(voices: SpeechSynthesisVoice[], lang: string): SpeechSynthesisVoice | undefined {
  const targetLang = lang.toLowerCase();
  
  // 1. Exact match with high quality
  const premium = voices.find(v => 
    v.lang.toLowerCase() === targetLang && 
    /natural|google|premium|enhanced|siri/i.test(v.name)
  );
  if (premium) return premium;

  // 2. Exact match any
  const exact = voices.find(v => v.lang.toLowerCase() === targetLang);
  if (exact) return exact;

  // 3. Prefix match (e.g., 'en' for 'en-US')
  const prefix = voices.find(v => v.lang.toLowerCase().startsWith(targetLang.split('-')[0]));
  if (prefix) return prefix;

  return undefined;
}

/**
 * Robust Speech Synthesis with fallback chain and duplicate prevention.
 */
export async function speak(
  text: string,
  opts: { accent?: Accent; rate?: number; onEnd?: () => void } = {},
) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) {
    opts.onEnd?.();
    return;
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  try {
    const voices = await loadVoices();
    const lang = opts.accent ?? "en-US";
    const u = new SpeechSynthesisUtterance(text);
    
    u.lang = lang;
    u.rate = opts.rate ?? 1;
    u.pitch = 1;
    u.volume = 1;

    const voice = findBestVoice(voices, lang);
    if (voice) u.voice = voice;

    u.onend = () => opts.onEnd?.();
    u.onerror = (e) => {
      console.error("[tts] error", e);
      opts.onEnd?.();
    };

    window.speechSynthesis.speak(u);
  } catch (err) {
    console.error("[tts] speak failed", err);
    opts.onEnd?.();
  }
}

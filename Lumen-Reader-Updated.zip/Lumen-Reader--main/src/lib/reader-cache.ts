/**
 * Context-aware translation cache for Lumen Reader.
 * Supports word-level and sentence-level caching while maintaining backward compatibility.
 */

const MEM = new Map<string, string>();
const LS_KEY = "reader.translations.v1";
const PENDING_REQUESTS = new Map<string, Promise<string>>();

export type TranslationContext = {
  word: string;
  sentence?: string;
  from?: string;
  to?: string;
};

function loadLS(): Record<string, string> {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(localStorage.getItem(LS_KEY) || "{}");
  } catch {
    return {};
  }
}

let lsSnapshot: Record<string, string> | null = null;
function ls(): Record<string, string> {
  if (!lsSnapshot) lsSnapshot = loadLS();
  return lsSnapshot;
}

/**
 * Generates a unique cache key based on word and surrounding context.
 */
function getCacheKey(ctx: string | TranslationContext): string {
  if (typeof ctx === "string") return ctx.toLowerCase().trim();
  
  const word = ctx.word.toLowerCase().trim();
  const from = (ctx.from || "en").toLowerCase();
  const to = (ctx.to || "ar").toLowerCase();
  
  if (!ctx.sentence) return `${word}:${from}:${to}`;
  
  // Normalize sentence: remove extra whitespace and truncate to prevent massive keys
  const normalizedSentence = ctx.sentence.trim().replace(/\s+/g, " ").slice(0, 500);
  return `${word}|${normalizedSentence}:${from}:${to}`;
}

export function getCached(ctx: string | TranslationContext): string | undefined {
  const key = getCacheKey(ctx);
  
  // 1. Check in-memory map
  if (MEM.has(key)) return MEM.get(key);
  
  // 2. Check localStorage snapshot
  const stored = ls()[key];
  if (stored) {
    MEM.set(key, stored);
    return stored;
  }
  
  // 3. Fallback for context-aware keys: if not found, check if we have a standalone word translation
  if (typeof ctx !== "string" && ctx.sentence) {
    const wordKey = getCacheKey({ ...ctx, sentence: undefined });
    return MEM.get(wordKey) || ls()[wordKey];
  }
  
  return undefined;
}

export function setCached(ctx: string | TranslationContext, translation: string) {
  const key = getCacheKey(ctx);
  MEM.set(key, translation);
  
  const all = ls();
  all[key] = translation;
  
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(all));
    } catch (e) {
      console.warn("[cache] localStorage quota exceeded", e);
    }
  }
}

const NO_TRANSLATION = "لا يوجد ترجمة متاحة";

/**
 * Clean up text for translation APIs
 */
function cleanQuery(text: string): string {
  return text.trim().replace(/\s+/g, " ");
}

/**
 * Validates if the result is a valid Arabic translation
 */
function isValidArabic(t: string, original: string): boolean {
  if (!t) return false;
  const cleanT = t.trim();
  if (cleanT.toLowerCase() === original.toLowerCase()) return false;
  return /[\u0600-\u06FF]/.test(cleanT);
}

async function tryMyMemory(query: string, original: string): Promise<string> {
  try {
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(cleanQuery(query))}&langpair=en|ar`;
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    const data = await res.json();
    const t = (data?.responseData?.translatedText as string);
    
    // MyMemory often returns the query if no translation is found
    if (isValidArabic(t, original)) return t.trim();
    return "";
  } catch {
    return "";
  }
}

async function tryLingva(query: string, original: string): Promise<string> {
  try {
    const res = await fetch(`https://lingva.ml/api/v1/en/ar/${encodeURIComponent(cleanQuery(query))}`, { 
      signal: AbortSignal.timeout(5000) 
    });
    if (!res.ok) return "";
    const data = await res.json();
    const t = (data?.translation as string);
    
    if (isValidArabic(t, original)) return t.trim();
    return "";
  } catch {
    return "";
  }
}

/**
 * Main translation function with context support and robust fallback chain.
 */
export async function translateWord(ctx: string | TranslationContext): Promise<string> {
  const context: TranslationContext = typeof ctx === "string" ? { word: ctx } : ctx;
  const key = getCacheKey(context);
  
  // 1. Check Cache
  const cached = getCached(context);
  if (cached) return cached;
  
  // 2. Prevent Duplicate Requests
  if (PENDING_REQUESTS.has(key)) return PENDING_REQUESTS.get(key)!;
  
  const translationPromise = (async () => {
    // Determine what to send to the API: prefer sentence for context, fallback to word
    const query = context.sentence || context.word;
    const original = context.word;
    
    // Strategy: 
    // If we have a sentence, try to translate the sentence. 
    // But since we want the translation of the WORD specifically, 
    // current free APIs might translate the whole sentence.
    // For now, we use the sentence as context if provided, but free APIs work best with shorter segments.
    
    // Fallback Chain
    let result = await tryMyMemory(query, original);
    if (!result) result = await tryLingva(query, original);
    
    // If sentence translation failed or returned the whole sentence, try word only
    if (!result && context.sentence) {
      result = await tryMyMemory(context.word, context.word);
      if (!result) result = await tryLingva(context.word, context.word);
    }
    
    const finalResult = result || NO_TRANSLATION;
    
    // Only cache successful results
    if (result) {
      setCached(context, result);
    }
    
    return finalResult;
  })();
  
  PENDING_REQUESTS.set(key, translationPromise);
  
  try {
    return await translationPromise;
  } finally {
    PENDING_REQUESTS.delete(key);
  }
}

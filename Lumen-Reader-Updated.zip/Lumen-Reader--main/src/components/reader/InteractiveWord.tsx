import { useEffect, useRef, useState } from "react";
import { VolumeX } from "lucide-react";
import { lookupWord } from "@/lib/dictionary";
import { loadSettings } from "@/lib/settings";
import { speak, type Accent } from "@/lib/tts";

type Props = {
  word: string;
  accent: Accent;
  rate: number;
  showTranslations: boolean;
  onSpoken?: (word: string) => void;
  onOpenPopup?: (word: string) => void;
};

export function InteractiveWord({ word, onSpoken }: Props) {
  const [open, setOpen] = useState(false);
  const [translation, setTranslation] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [noAudio, setNoAudio] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const ref = useRef<HTMLSpanElement | null>(null);
  const timerRef = useRef<number | null>(null);
  const isPlayingRef = useRef(false);

  const clearTimer = () => {
    if (timerRef.current) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  const scheduleClose = () => {
    clearTimer();
    const duration = loadSettings().popupDurationMs;
    timerRef.current = window.setTimeout(() => setOpen(false), duration);
  };

  useEffect(() => {
    if (!open) return;
    const onDocClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, [open]);

  useEffect(() => () => clearTimer(), []);

  const playPronunciation = async (audioUrl: string, settings: any) => {
    if (isPlayingRef.current) return;
    isPlayingRef.current = true;

    const accent = settings.accentOrder?.[0] === "us" ? "en-US" : "en-GB";
    const rate = settings.rate || 1;

    // Fallback Chain Strategy:
    // 1. Dictionary Audio File (High Quality)
    // 2. Browser Speech Synthesis (Fallback)
    
    if (audioUrl && settings.autoPronounce) {
      setNoAudio(false);
      try {
        if (audioRef.current) {
          audioRef.current.pause();
          audioRef.current.src = "";
        }
        
        const audio = new Audio(audioUrl);
        audio.playbackRate = rate;
        audioRef.current = audio;
        
        await audio.play().catch(async (err) => {
          console.warn("[pron] Audio file play failed, trying TTS", err);
          await speak(word, { accent, rate });
        });
      } catch (err) {
        console.warn("[pron] Audio object error, trying TTS", err);
        await speak(word, { accent, rate });
      }
    } else if (settings.autoPronounce) {
      await speak(word, { accent, rate, onEnd: () => {
        // If TTS fails to produce sound, it might still trigger onEnd
      }});
      setNoAudio(false); // TTS is our reliable fallback
    } else {
      setNoAudio(!audioUrl);
    }
    
    isPlayingRef.current = false;
  };

  const handleClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setOpen(true);
    setLoading(true);
    onSpoken?.(word);

    const settings = loadSettings();

    try {
      const entry = await lookupWord(word, { word });
      setTranslation(entry?.translation || "لا يوجد ترجمة متاحة");
      setLoading(false);
      scheduleClose();

      let audioUrl = entry?.audio || "";
      if (audioUrl.startsWith("//")) audioUrl = "https:" + audioUrl;

      await playPronunciation(audioUrl, settings);
    } catch (err) {
      console.error("[pron] lookup failed", err);
      setTranslation("خطأ في التحميل");
      setLoading(false);
    }
  };

  return (
    <span ref={ref} className="relative inline-block">
      <span
        className={`interactive-word ${open ? "speaking" : ""}`}
        onClick={handleClick}
      >
        {word}
      </span>
      {open && (
        <span
          role="tooltip"
          dir="rtl"
          className="pointer-events-none absolute left-1/2 -translate-x-1/2 bottom-full mb-2 z-40 whitespace-nowrap rounded-lg bg-foreground text-background text-[13px] font-medium px-2.5 py-1.5 inline-flex items-center gap-1.5 font-arabic"
          style={{
            animation: "var(--animate-tooltip-in)",
            boxShadow: "var(--shadow-popover)",
          }}
        >
          <span>{loading ? "…" : translation}</span>
          {!loading && noAudio && (
            <VolumeX aria-label="No pronunciation available" className="size-3 opacity-60" />
          )}
          <span className="absolute left-1/2 -translate-x-1/2 top-full size-0 border-x-[5px] border-x-transparent border-t-[5px] border-t-foreground" />
        </span>
      )}
    </span>
  );
}
